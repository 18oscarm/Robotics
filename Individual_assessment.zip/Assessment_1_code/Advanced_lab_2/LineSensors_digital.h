/***************************************
 ,        .       .           .     ,-.  
 |        |       |           |        ) 
 |    ,-: |-. ,-. |-. ,-. ,-. |-      /  
 |    | | | | `-. | | |-' |-' |      /   
 `--' `-` `-' `-' ' ' `-' `-' `-'   '--' 
****************************************/

#ifndef _LINESENSORS_H
#define _LINESENSORS_H

#define NUM_SENSORS 5
#define LINE_THRESHOLD 0.85
#define EMIT_PIN 11
#define DIGITAL_TIMEOUT_US 3000  // 3ms timeout for digital reads

// Analog pins for ADC readings
const int sensor_pins[NUM_SENSORS] = {A11, A0, A2, A3, A4};
// Digital pins for discharge timing (DN1-DN5)
const int digital_sensor_pins[NUM_SENSORS] = {12, 18, 20, 21, 22};

class LineSensors_c {
  public:
    // Existing ADC-related members
    float readings[NUM_SENSORS];
    float scaling[NUM_SENSORS];
    float calibrated[NUM_SENSORS];

    // New digital calibration variables
    unsigned long min_digital[NUM_SENSORS] = {3000};  // Initialize to timeout
    unsigned long max_digital[NUM_SENSORS] = {0};
    float calibrated_digital[NUM_SENSORS];

    // Constructor remains unchanged
    LineSensors_c() {}

   
    // ==============================================
    // New Digital Reading Functions
    // ==============================================

    void initialiseForDigital() {
      pinMode(EMIT_PIN, OUTPUT);
      digitalWrite(EMIT_PIN, HIGH);
    }

    unsigned long digitalReadSensor(int sensor_index) {
      if(sensor_index < 0 || sensor_index >= NUM_SENSORS) return 0;
      
      int pin = digital_sensor_pins[sensor_index];
      
      // Charge capacitor
      pinMode(pin, OUTPUT);
      digitalWrite(pin, HIGH);
      delayMicroseconds(10);
      pinMode(pin, INPUT);

      // Measure discharge time with timeout
      unsigned long start_time = micros();
      while(digitalRead(pin) == HIGH) {
        if(micros() - start_time > DIGITAL_TIMEOUT_US) break;
      }
      unsigned long end_time = micros();

      return end_time - start_time;
    }

    void readSensorsDigital() {
      initialiseForDigital();
      for(int i = 0; i < NUM_SENSORS; i++) {
        readings[i] = digitalReadSensor(i);
      }
      pinMode(EMIT_PIN, INPUT);  // Turn off IR LEDs
    }

    void calibrate_line_sensors_digital() {
      readSensorsDigital();
      
      for(int n = 0; n < NUM_SENSORS; n++) {
        // Update minima and maxima
        if(readings[n] < min_digital[n]) min_digital[n] = readings[n];
        if(readings[n] > max_digital[n]) max_digital[n] = readings[n];
      }
    }

    // Apply digital calibration
    void calcCalibratedDigital() {
      readSensorsDigital();
      
      for(int sensor = 0; sensor < NUM_SENSORS; sensor++) {
        float range = max_digital[sensor] - min_digital[sensor];
        if(range <= 0) {
          calibrated_digital[sensor] = 0.0;
        } else {
          // Invert to match ADC interpretation (1.0=white)
          calibrated_digital[sensor] = 1.0 - ((readings[sensor] - min_digital[sensor]) / range);
        }
      }
    }
}; // End of LineSensors_c class

#endif